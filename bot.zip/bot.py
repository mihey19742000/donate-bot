import asyncio
import logging
from aiohttp import web
from aiogram import Bot, Dispatcher
from aiogram.enums import ParseMode
from aiogram.client.default import DefaultBotProperties
import sys
import os

sys.path.insert(0, os.path.dirname(__file__))

from config import BOT_TOKEN
from handlers.commands import router as commands_router

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Простой веб-сервер, чтобы Render видел порт
async def handle(request):
    return web.Response(text="Bot is running!")

async def main():
    bot = Bot(
        token=BOT_TOKEN,
        default=DefaultBotProperties(parse_mode=ParseMode.HTML)
    )
    dp = Dispatcher()
    dp.include_router(commands_router)

    # Веб-сервер
    app = web.Application()
    app.router.add_get('/', handle)
    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, '0.0.0.0', 10000)
    await site.start()
    
    logger.info("Бот запущен!")
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())